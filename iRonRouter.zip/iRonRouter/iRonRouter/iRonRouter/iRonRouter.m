//
//  iRonRouter.m
//  iRonRouter
//
//  Created by iRonCheng on 2017/8/18.
//  Copyright © 2017年 iRonCheng. All rights reserved.
//

#import "iRonRouter.h"
#import "iRonRouterError.h"

/* 忽略 (会发生内存泄漏的)警告⚠️ */
#define SuppressPerformSelectorLeakWarning(Stuff) \
do { \
_Pragma("clang diagnostic push") \
_Pragma("clang diagnostic ignored \"-Warc-performSelector-leaks\"") \
Stuff; \
_Pragma("clang diagnostic pop") \
} while (0)

@implementation iRonRouter

/* 单例 */
+ (iRonRouter *)sharedInstance
{
    static dispatch_once_t onceToken;
    static iRonRouter * router;
    dispatch_once(&onceToken,^{
        router = [[iRonRouter alloc] init];
    });
    return router;
}

#pragma mark - 根据nameString获取viewController

- (UIViewController *)getViewControllerWithName:(NSString *)VCNameString
{
    Class class = NSClassFromString(VCNameString);
    
    UIViewController *controller = [[class alloc] init];
    /*  找不到这个类
     *  此处可以跳转到一个错误提示页面
     */
    if(controller == nil){
        NSLog(@"未定义此类:%@",VCNameString);
        controller = [[iRonRouterError sharedInstance] getErrorViewController];
    }
    
    return controller;
}

- (UIViewController *)getViewControllerWithName:(NSString *)VCNameString andParam:(NSDictionary *)paramDict
{
    
    UIViewController *controller = [self getViewControllerWithName:VCNameString];
    
    controller = [self controller:controller withParam:paramDict andNameString:VCNameString];
    
    return controller;
    
}

#pragma mark - Privated Method

- (UIViewController *)controller:(UIViewController *)controller withParam:(NSDictionary *)paramdic andNameString:(NSString *)vcName {
    
    /* viewController里面初始化参数的方法 */
    SEL selector = NSSelectorFromString(@"initVCParam:");
    
    //如果没定义初始化参数方法，直接返回，没必要在往下做设置参数的方法
    if(![controller respondsToSelector:selector]){
        NSLog(@"目标类:%@未定义:%@方法",controller,@"iniViewControllerParam:");
        
        return controller;
        
    } else {
        
        NSMutableDictionary *dict = [NSMutableDictionary dictionaryWithDictionary:paramdic];
        // URLKEY  页面唯一路径标识别
        /* 参数一定要有个URLKEY  */
        [dict setValue:vcName forKey:@"URLKEY"];
        /* 忽略警告的情况下，执行初始化参数的方法 
         * 因为ARC下，是在编译阶段自动加上释放内存的代码，但是这里的方法是运行时动态加的，所以没加释放内存的代码，有可能内存溢出
         */
        SuppressPerformSelectorLeakWarning( [controller performSelector:selector withObject:dict]);
        
        return controller;
    }
}

@end
