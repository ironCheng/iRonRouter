//
//  iRonDemoFirstViewController.m
//  iRonRouter
//
//  Created by iRonCheng on 2017/8/18.
//  Copyright © 2017年 iRonCheng. All rights reserved.
//

#import "iRonDemoFirstViewController.h"

@interface iRonDemoFirstViewController ()

@property (nonatomic, strong) UILabel *firstLabel;
@property (nonatomic, strong) UILabel *secondLabel;

@property (nonatomic, strong) UIWebView *webView;

@end

@implementation iRonDemoFirstViewController

- (void)initVCParam:(NSDictionary *)paramDict
{
    [self setupViews];
    
    NSLog(@"initVCParam ,paramDict = %@",paramDict);
    
    _firstLabel.text = paramDict[@"firstString"];
    _secondLabel.text = paramDict[@"secondString"];
    
    NSMutableURLRequest *mutableRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:paramDict[@"webUrl"]]];
    [self.webView loadRequest:mutableRequest];
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"firstViewController";
    self.view.backgroundColor = [UIColor blueColor];

}

- (void)setupViews
{
    _firstLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 50, [UIScreen mainScreen].bounds.size.width, 20)];
    _firstLabel.textColor = [UIColor whiteColor];
    
    _secondLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 100, [UIScreen mainScreen].bounds.size.width, 20)];
    _secondLabel.textColor = [UIColor whiteColor];
    
    _webView = [[UIWebView alloc] initWithFrame:CGRectMake(0, [UIScreen mainScreen].bounds.size.height/2, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height/2)];
    
    [self.view addSubview:_firstLabel];
    [self.view addSubview:_secondLabel];
    [self.view addSubview:_webView];
    
    
    UIButton *button = [[UIButton alloc] initWithFrame:CGRectMake([UIScreen mainScreen].bounds.size.width-50, 0, 50, 50)];
    [button setTitle:@"back" forState:UIControlStateNormal];
    [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [button addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button];
    
}

- (void)back {
    [self dismissViewControllerAnimated:YES completion:nil];
}



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
