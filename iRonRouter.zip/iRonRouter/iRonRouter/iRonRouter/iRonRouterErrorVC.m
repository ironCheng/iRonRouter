//
//  iRonRouterErrorVC.m
//  iRonRouter
//
//  Created by iRonCheng on 2017/8/18.
//  Copyright © 2017年 iRonCheng. All rights reserved.
//

#import "iRonRouterErrorVC.h"

@interface iRonRouterErrorVC ()

@end

@implementation iRonRouterErrorVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"warn: 未找到页面";
    self.view.backgroundColor = [UIColor whiteColor];

    UIButton *button = [[UIButton alloc] initWithFrame:CGRectMake([UIScreen mainScreen].bounds.size.width-50, 0, 50, 50)];
    [button setTitle:@"back" forState:UIControlStateNormal];
    [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [button addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button];
}

- (void)back {
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
