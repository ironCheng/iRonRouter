//
//  iRonRouter.h
//  iRonRouter
//
//  Created by iRonCheng on 2017/8/18.
//  Copyright © 2017年 iRonCheng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface iRonRouter : NSObject

/* 单例 */
+ (iRonRouter *)sharedInstance;

#pragma mark - 根据nameString获取viewController

- (UIViewController *)getViewControllerWithName:(NSString *)VCNameString;
- (UIViewController *)getViewControllerWithName:(NSString *)VCNameString andParam:(NSDictionary *)paramDict;

@end
