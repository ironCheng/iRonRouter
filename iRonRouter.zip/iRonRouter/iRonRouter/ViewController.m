//
//  ViewController.m
//  iRonRouter
//
//  Created by iRonCheng on 2017/8/18.
//  Copyright © 2017年 iRonCheng. All rights reserved.
//

#import "ViewController.h"
#import "iRonRouter.h"
#import "iRonDemoFirstViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UILabel *lable = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 100, 50)];
    lable.textColor = [UIColor blueColor];
    lable.text =@"hello word";
    [self.view addSubview:lable];
    
    UIButton *button = [[UIButton alloc] initWithFrame:CGRectMake(0, 50, 200, 50)];
    [button setTitle:@"访问iRonDemoFirstViewController" forState:UIControlStateNormal];
    [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    button.tag = 1;
    [button addTarget:self action:@selector(back:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button];
    
    UIButton *button2 = [[UIButton alloc] initWithFrame:CGRectMake(0, 110, 200, 50)];
    [button2 setTitle:@"访问iRonDemoSecondViewController" forState:UIControlStateNormal];
    [button2 setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    button2.tag = 2;
    [button2 addTarget:self action:@selector(back:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button2];
    
    UIButton *butto3 = [[UIButton alloc] initWithFrame:CGRectMake(0, 170, 200, 50)];
    [butto3 setTitle:@"访问iRonDemoFirstViewController,无参数" forState:UIControlStateNormal];
    [butto3 setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    butto3.tag = 3;
    [butto3 addTarget:self action:@selector(back:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:butto3];
    
    UIButton *button4 = [[UIButton alloc] initWithFrame:CGRectMake(0, 230, 200, 50)];
    [button4 setTitle:@"错误的页面" forState:UIControlStateNormal];
    [button4 setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    button4.tag = 4;
    [button4 addTarget:self action:@selector(back:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button4];
    
}

-(void)back:(UIButton *)btn
{
    switch (btn.tag) {
        case 1:
        {
            UIViewController *vc = [[iRonRouter sharedInstance] getViewControllerWithName:@"iRonDemoFirstViewController" andParam:@{@"webUrl":@"https://www.baidu.com",@"firstString":@"这是第一行吧。。",@"secondString":@"这里是baidu.com的页面吧"}];
            [self presentViewController:vc animated:YES completion:nil];
            
        }
            break;
        case 2:
        {
            UIViewController *vc = [[iRonRouter sharedInstance] getViewControllerWithName:@"iRonDemoSecondViewController" andParam:@{@"webUrl":@"https://www.sina.com.cn",@"firstString":@"这是第一行吧。。",@"secondString":@"这里应该是sina.com的页面吧。。"}];
            [self presentViewController:vc animated:YES completion:nil];
        }
            break;
        case 3:
        {
            UIViewController *vc = [[iRonRouter sharedInstance] getViewControllerWithName:@"iRonDemoFirstViewController" andParam:nil];
            [self presentViewController:vc animated:YES completion:nil];
        }
            break;
        case 4:
        {
            /* 错误的ViewController */
            UIViewController *vc = [[iRonRouter sharedInstance] getViewControllerWithName:@"iRonWrongViewController" andParam:@{@"webUrl":@"https://www.baidu.com",@"firstString":@"这是第一行吧。。",@"secondString":@"第二行？？？？？"}];
            [self presentViewController:vc animated:YES completion:nil];
        }
            break;
            
        default:
            break;
    }
    
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
