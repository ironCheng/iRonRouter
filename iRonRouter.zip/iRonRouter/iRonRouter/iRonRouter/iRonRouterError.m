//
//  iRonRouterError.m
//  iRonRouter
//
//  Created by iRonCheng on 2017/8/18.
//  Copyright © 2017年 iRonCheng. All rights reserved.
//
//      一定要有个错误的处理方法，保证可以跳到的VC
//

#import "iRonRouterError.h"
#import "iRonRouterErrorVC.h"

@implementation iRonRouterError

+ (iRonRouterError *)sharedInstance
{
    static dispatch_once_t onceToken;
    static iRonRouterError * routerError;
    dispatch_once(&onceToken,^{
        routerError = [[iRonRouterError alloc] init];
    });
    
    return routerError;
}

#pragma mark  自定义错误页面 此页面一定确保能够找到

- (UIViewController *)getErrorViewController
{
    iRonRouterErrorVC *errorVC = [iRonRouterErrorVC new];
    return errorVC;
    
}

@end
